import pandas as pd
import os

def predict_housing_types(input_path, output_path):
    """
    Reads housing data, filters for future years (2025-2035),
    and saves the predictions to a CSV file.

    Args:
        input_path (str): The path to the input CSV file.
        output_path (str): The path where the output CSV file should be saved.
    """
    try:
        # Read the input CSV
        df = pd.read_csv(input_path)

        # Filter for years between 2025 and 2035 (inclusive of 2025, exclusive of 2036)
        df_filtered = df[(df['Year'] >= 2025) & (df['Year'] < 2036)].copy() # Use .copy() to avoid SettingWithCopyWarning

        # Ensure the output directory exists
        output_dir = os.path.dirname(output_path)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            print(f"Created directory: {output_dir}")

        # Save the filtered data to the output CSV
        df_filtered.to_csv(output_path, index=False)
        print(f"Housing type predictions saved to {output_path}")

    except FileNotFoundError:
        print(f"Error: Input file not found at {input_path}")
    except KeyError as e:
        print(f"Error: Column '{e}' not found in the input file. Please ensure the CSV has a 'Year' column.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == '__main__':
    # Example usage when running the script directly (optional)
    # Define relative paths based on the project structure
    # Assuming the script is run from the root directory 'code_structure'
    DEFAULT_INPUT = os.path.join('data', 'processed', 'housing', 'Housing_Types_Merged.csv')
    DEFAULT_OUTPUT = os.path.join('data', 'forecasted', 'housing_type_predictions.csv')

    predict_housing_types(DEFAULT_INPUT, DEFAULT_OUTPUT)
