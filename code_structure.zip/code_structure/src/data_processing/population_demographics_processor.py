# [script1 - Updated]
import pandas as pd
import logging
import os # Keep os for the __main__ block if needed later, but not strictly for content matching

# Configure basic logging (Kept for structure, doesn't affect output content)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def correct_population_dataset(
    file_path: str,
    canada_population_file: str,
    provinces_age_gender_file: str,
    canada_age_gender_file: str,
    output_path: str | None = None
) -> pd.DataFrame | None:
    """
    Corrects population timeseries, integrates age/gender data, and merges demographic info.
    (Logic modified to match script2 for identical output content).

    Args:
        file_path: Path to the base population timeseries CSV.
        canada_population_file: Path to the official Canada population data CSV.
        provinces_age_gender_file: Path to the provinces age/gender distribution CSV.
        canada_age_gender_file: Path to the Canada age/gender distribution CSV.
        output_path: Optional path to save the final cleaned dataset CSV.

    Returns:
        A pandas DataFrame containing the final cleaned and merged data, or None if an error occurs.
    """
    try:
        logging.info("Loading base demographic data...") # Logging kept
        df = pd.read_csv(file_path)
        df['Province'] = df['Province'].str.strip()
        df_unique = df.drop_duplicates(subset=["Year", "Province"])
        df_unique = df_unique[df_unique["Year"] >= 1991]
        logging.info(f"Base data loaded. Shape after initial filtering: {df_unique.shape}") # Logging kept

        logging.info("Loading official Canada population data...") # Logging kept
        canada_population_df = pd.read_csv(canada_population_file)
        canada_population_df = canada_population_df[canada_population_df["Year"].isin(df_unique["Year"].unique())]
        logging.info(f"Canada population data loaded. Shape after year filtering: {canada_population_df.shape}") # Logging kept

        common_columns = ["Year", "Province", "Total PRs", "Total TRs", "Total Births", "Total Deaths", "Population Estimate"]
        df_unique = df_unique[common_columns]
        canada_population_df = canada_population_df[common_columns]

        logging.info("Recalculating 'Canada' totals based on provincial sums (matching script2 logic)...") # Logging kept
        df_corrected = df_unique[df_unique["Province"] != "Canada"].copy() # Use .copy() to avoid SettingWithCopyWarning
        # Group by Year only and sum (like script2 - might sum Population Estimate too, but combine_first handles it)
        grouped_df = df_corrected.groupby('Year', as_index=False)[['Total PRs', 'Total TRs', 'Total Births', 'Total Deaths']].sum()
        grouped_df['Province'] = 'Canada'

        # Match script2's update logic using combine_first on Year index
        canada_population_df = canada_population_df.set_index('Year')
        grouped_df_indexed = grouped_df.set_index('Year') # Create indexed version for combine_first

        # Update only the specified columns using combine_first (prioritizes grouped_df values)
        for col in ['Total PRs', 'Total TRs', 'Total Births', 'Total Deaths']:
             # Check if column exists in grouped_df_indexed before combining
             if col in grouped_df_indexed.columns:
                 canada_population_df[col] = grouped_df_indexed[col].combine_first(canada_population_df[col])

        canada_population_df = canada_population_df.reset_index()

        df_final = pd.concat([df_corrected, canada_population_df], ignore_index=True)
        df_final = df_final.sort_values(by=["Year", "Province"]).reset_index(drop=True)
        logging.info(f"Provincial and corrected Canada data combined. Shape: {df_final.shape}") # Logging kept

        # --- Clean Age-Gender Data (matching script2 logic) ---
        logging.info("Cleaning age and gender distribution data (matching script2 logic)...") # Logging kept
        def clean_age_gender(df_ag):
            df_ag = df_ag[['REF_DATE', 'GEO', 'Gender', 'Age group', 'VALUE']].copy()
            df_ag.columns = ['Year_Str', 'Province', 'Gender', 'Age_Group', 'Population'] # Temp name for REF_DATE
            df_ag['Province'] = df_ag['Province'].str.strip()
            df_ag = df_ag[df_ag['Gender'].isin(['Men+', 'Women+'])].dropna(subset=['Population'])
            # Match script2's date handling
            df_ag['Year_DT'] = pd.to_datetime(df_ag['Year_Str'].astype(str) + '-01-01', errors='coerce') # Create datetime
            df_ag = df_ag.dropna(subset=['Year_DT']) # Drop if conversion failed
            df_ag['REF_DATE'] = df_ag['Year_DT'].dt.strftime('01-%m-%Y') # Create REF_DATE string
            df_ag['Year'] = df_ag['Year_DT'].dt.year # Extract Year integer
            df_ag = df_ag[df_ag['Year'] >= 1991]
            # Return columns matching script2's implicit structure before pivot
            return df_ag[['REF_DATE', 'Year', 'Province', 'Gender', 'Age_Group', 'Population']]

        provinces_df = pd.read_csv(provinces_age_gender_file)
        canada_df = pd.read_csv(canada_age_gender_file)
        provinces_clean = clean_age_gender(provinces_df)
        canada_clean = clean_age_gender(canada_df)
        combined = pd.concat([provinces_clean, canada_clean], ignore_index=True)
        logging.info(f"Combined and cleaned age/gender data shape: {combined.shape}") # Logging kept

        # --- Pivot to Male/Female columns (matching script2 logic) ---
        logging.info("Pivoting age/gender data (matching script2 logic)...") # Logging kept
        pivoted = combined.pivot_table(
            index=['REF_DATE', 'Year', 'Province', 'Age_Group'],
            columns='Gender',
            values='Population',
            aggfunc='sum' # Use sum like script2
        ).reset_index().rename(columns={'Men+': 'Male_Population', 'Women+': 'Female_Population'})

        # Match script2: Assume columns exist and calculate directly, no NaN fill here
        # Ensure columns exist before calculation, fill missing with NaN (which + will propagate)
        if 'Male_Population' not in pivoted.columns: pivoted['Male_Population'] = pd.NA
        if 'Female_Population' not in pivoted.columns: pivoted['Female_Population'] = pd.NA
        pivoted['Combined_Population'] = pivoted['Male_Population'] + pivoted['Female_Population']
        logging.info(f"Pivoted data shape: {pivoted.shape}") # Logging kept

        # --- Filter only valid, non-overlapping age groups (matching script2 map) ---
        logging.info("Mapping and filtering age group categories (matching script2 map)...") # Logging kept
        # Use script2's exact map
        age_group_map = {
            '0 to 14 years': 'Children (0–14)',    # Match script2's en dash
            '15 to 64 years': 'Working Age (15–64)', # Match script2's en dash
            '90 years and older': 'Elderly (90+)',    # Match script2's name
            'All ages': 'All Ages'                 # Match script2's name
        }
        pivoted['Age_Group_Category'] = pivoted['Age_Group'].map(age_group_map)
        # Filter directly on pivoted, like script2
        pivoted = pivoted.dropna(subset=['Age_Group_Category'])
        logging.info(f"Data shape after mapping age groups: {pivoted.shape}") # Logging kept

        # --- Aggregate gender and combined values (matching script2 logic) ---
        logging.info("Aggregating mapped age group data (matching script2 logic)...") # Logging kept
        # Add script2's aggregation step
        aggregated = pivoted.groupby(['REF_DATE', 'Year', 'Province', 'Age_Group_Category']).agg({
            'Male_Population': 'sum',
            'Female_Population': 'sum',
            'Combined_Population': 'sum'
        }).reset_index()
        logging.info(f"Aggregated data shape: {aggregated.shape}") # Logging kept


        # --- Merge demographic totals for birth/death/estimate data (matching script2 logic) ---
        logging.info("Merging aggregated age/gender data with population totals...") # Logging kept
        demographic_info = df_final[['Year', 'Province', 'Total PRs', 'Total TRs', 'Total Births', 'Total Deaths', 'Population Estimate']]
        # Match script2: Do *not* drop duplicates here
        # final_merged_df = pd.merge(aggregated, demographic_info, on=['Year', 'Province'], how='left') # Original name
        # Use final_df as variable name like script2 does at this stage
        final_df = pd.merge(aggregated, demographic_info, on=['Year', 'Province'], how='left')
        logging.info(f"Shape after merging with population totals: {final_df.shape}") # Logging kept

        # --- Fill missing values from 'All Ages' row within same year-province (matching script2 logic) ---
        logging.info("Filling missing demographic totals using 'All Ages' reference (matching script2 logic)...") # Logging kept
        # Use script2's exact function implementation
        def fill_missing_from_all_ages(df):
            fill_cols = ['Total PRs', 'Total TRs', 'Total Births', 'Total Deaths', 'Population Estimate']
            # Match script2: No drop_duplicates here
            all_ages_ref = df[df['Age_Group_Category'] == 'All Ages'][['Year', 'Province'] + fill_cols].copy() # Added .copy() for safety

            # Match script2: Use merge/fillna approach
            df_filled = pd.merge(
                df,
                all_ages_ref,
                on=['Year', 'Province'],
                suffixes=('', '_ref'),
                how='left'
            )

            for col in fill_cols:
                # Ensure ref column exists before trying to fill (handles cases where 'All Ages' might be missing)
                if f'{col}_ref' in df_filled.columns:
                    df_filled[col] = df_filled[col].fillna(df_filled[f'{col}_ref'])
                    df_filled.drop(columns=[f'{col}_ref'], inplace=True)
                else:
                     logging.warning(f"Reference column {col}_ref not found during fillna step. Check 'All Ages' data.")


            return df_filled

        final_df = fill_missing_from_all_ages(final_df) # Use final_df variable name
        logging.info(f"Shape after filling missing values: {final_df.shape}") # Logging kept

        # Match script2: No final column selection or sorting step here.
        # The order will be determined by the previous merge and fill operations.

        # --- Export final version ---
        if output_path:
            try:
                # Save the final DataFrame (now named final_df)
                final_df.to_csv(output_path, index=False)
                logging.info(f"✅ Final cleaned dataset saved to {output_path}") # Logging kept
            except Exception as e:
                logging.error(f"Error saving final dataset to {output_path}: {e}") # Error handling kept
                return None # Indicate failure if saving fails

        # Return the DataFrame whose content now matches script2's output
        return final_df

    except FileNotFoundError as e: # Error handling kept
        logging.error(f"Missing input file: {e.filename}")
        return None
    except KeyError as e: # Error handling kept
        logging.error(f"Missing expected column in input data: {e}")
        return None
    except Exception as e: # Error handling kept
        logging.error(f"An unexpected error occurred during population demographics processing: {e}")
        import traceback
        logging.error(traceback.format_exc()) # Log full traceback for debugging
        return None

# Example Usage (Kept for testing, doesn't affect function's output content)
if __name__ == '__main__':
    # Define paths relative to the project root for standalone testing
    # Adjust these paths if running the script directly from its location
    # Using dummy paths for demonstration if needed
    base_dir_test = '../../' # Assuming script is in src/data_processing/
    raw_dir_test = os.path.join(base_dir_test, 'data', 'raw')
    processed_dir_test = os.path.join(base_dir_test, 'data', 'processed')

    # Check if directories/files exist before running, replace with actual paths for testing
    test_file_path = "path/to/Population Timeseries.csv" # Replace with actual path
    test_canada_population_file = "path/to/canada_population_data.csv" # Replace with actual path
    test_provinces_age_gender_file = "path/to/Demographic_data/Age Gender Distribution Provinces.csv" # Replace with actual path
    test_canada_age_gender_file = "path/to/Demographic_data/Age Gender Distribution Canada.csv" # Replace with actual path
    test_output_csv = os.path.join(processed_dir_test, 'Population_Demographics_by_Year_and_Province_and_Canada_TEST_matched.csv') # Changed name slightly

    print(f"Running test with output to: {test_output_csv}")
    # Ensure the processed directory exists for testing
    # os.makedirs(processed_dir_test, exist_ok=True) # Uncomment if needed

    # Dummy check for file existence before running example
    files_exist = all(os.path.exists(p) for p in [test_file_path, test_canada_population_file, test_provinces_age_gender_file, test_canada_age_gender_file])

    if files_exist:
         os.makedirs(processed_dir_test, exist_ok=True) # Ensure output dir exists
         final_df_test = correct_population_dataset(
             test_file_path,
             test_canada_population_file,
             test_provinces_age_gender_file,
             test_canada_age_gender_file,
             output_path=test_output_csv
         )

         if final_df_test is not None:
             print("✅ Test execution completed successfully.")
             print(f"Output saved to {test_output_csv}")
             print("First 5 rows of the output:")
             print(final_df_test.head())
         else:
             print("❌ Test execution failed. Check logs for details.")
    else:
        print("❌ Test execution skipped. Input files not found at specified paths.")
        print(f"Checked paths:\n - {test_file_path}\n - {test_canada_population_file}\n - {test_provinces_age_gender_file}\n - {test_canada_age_gender_file}")