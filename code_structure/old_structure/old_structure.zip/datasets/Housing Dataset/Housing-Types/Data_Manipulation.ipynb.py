# %%
import pandas as pd
import numpy as np

# %%
df= pd.read_csv('number-households-tenure-ownership-rate-1976-2036-2015-en(Canada).csv', encoding="latin1")

# %% [markdown]
# # Removing low and high estimates and keeping the medium projections
# 

# %%
df = df.drop(df.index[10:15])


# %%
df.reset_index(drop=True, inplace=True)

# %%
df = df.drop(df.index[15:])


# %%
df = df.drop(df.index[20:])

# %%
# Making the second row our columns

# %%
df.columns = df.iloc[1]  # Set the second row as column names
df = df.drop([0, 1])

# %%
df.head()

# %%
# Renaming the second column to Year
df.columns.values[1] = 'Year'
df.columns.values[7] = 'Owners'
df.columns.values[11] = 'Renter'
df.columns.values[8:11] = ['Owner-' + col for col in df.columns.values[8:11]]
df.columns.values[12:] = ['Renter-' + col for col in df.columns.values[12:]]



# %%
df

# %%
#Dropping the first column
df.drop(df.columns[0], axis=1, inplace=True)

# %%
df.head(3)

# %%
df.info()

# %%
# Convert Year column to numeric
df['Year'] = pd.to_numeric(df['Year'], errors='coerce')

# Set Year as index
df.set_index('Year', inplace=True)
    
# Reindex for missing years
df = df.reindex(range(int(df.index.min()), 2037))

# %%
df.columns

# %%

    # Convert data column to numeric
df['Total'] = df['Total'].replace({',': ''}, regex=True)
df['Total'] = pd.to_numeric(df['Total'], errors='raise')

df['Ownership rate'] = pd.to_numeric(df['Ownership rate'], errors='coerce')

df['Single-detached'] = df['Single-detached'].replace({',': ''}, regex=True)
df['Single-detached'] = pd.to_numeric(df['Single-detached'], errors='raise')

df['Apartments'] = df['Apartments'].replace({',': ''}, regex=True)
df['Apartments'] = pd.to_numeric(df['Apartments'], errors='coerce')

df['Other dwellings'] = df['Other dwellings'].replace({',': ''}, regex=True)
df['Other dwellings'] = pd.to_numeric(df['Other dwellings'], errors='coerce')

df['Owners'] = df['Owners'].replace({',': ''}, regex=True)
df['Owners'] = pd.to_numeric(df['Owners'], errors='coerce')

df['Owner-Single-detached'] = df['Owner-Single-detached'].replace({',': ''}, regex=True)
df['Owner-Single-detached'] = pd.to_numeric(df['Owner-Single-detached'], errors='coerce')

df['Owner-Apartments'] = df['Owner-Apartments'].replace({',': ''}, regex=True)
df['Owner-Apartments'] = pd.to_numeric(df['Owner-Apartments'], errors='coerce')

df['Owner-Other dwellings'] = df['Owner-Other dwellings'].replace({',': ''}, regex=True)
df['Owner-Other dwellings'] = pd.to_numeric(df['Owner-Other dwellings'], errors='coerce')

df['Owner-Single-detached'] = df['Owner-Single-detached'].replace({',': ''}, regex=True)
df['Owner-Single-detached'] = df['Owner-Single-detached'].replace({',': ''}, regex=True)

df['Renter'] = df['Renter'].replace({',': ''}, regex=True)
df['Renter'] = pd.to_numeric(df['Renter'], errors='coerce')

df['Renter-Single-detached'] = df['Renter-Single-detached'].replace({',': ''}, regex=True)
df['Renter-Single-detached'] = pd.to_numeric(df['Renter-Single-detached'], errors='coerce')

df['Renter-Apartments'] = df['Renter-Apartments'].replace({',': ''}, regex=True)
df['Renter-Apartments'] = pd.to_numeric(df['Renter-Apartments'], errors='coerce')

df['Renter-Other dwellings'] = df['Renter-Other dwellings'].replace({',': ''}, regex=True)
df['Renter-Other dwellings'] = pd.to_numeric(df['Renter-Other dwellings'], errors='coerce')


# %%
df= df.interpolate(method='linear', axis=0, limit=None, inplace=False, limit_direction='both', limit_area=None)

# %%
#Multiplying everything by 1000 except of rate

# %%
df.iloc[:, 1:] = (df.iloc[:, 1:] * 1000)

# %%
df=df.round(0).astype(int)

# %%
df['Gep']= 'Canada'

# %%
df

# %%



