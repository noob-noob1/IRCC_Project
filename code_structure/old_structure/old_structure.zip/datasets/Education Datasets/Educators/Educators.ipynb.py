# %%
import pandas as pd

# %%
file_path = "Educators in public elementary and secondary schools.csv"
df = pd.read_csv(file_path)

# %%
df.head()

# %%
# Keep only the left year
df['REF_DATE'] = df['REF_DATE'].str[:4]

# %%
df.head()

# %%
# Define the list of GEO values to keep
geo_list = [
    "Canada", "Quebec", "Ontario", "British Columbia", "Alberta", 
    "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Saskatchewan", "Prince Edward Island"
]

# Filter the DataFrame to keep only these GEO values
df = df[df['GEO'].isin(geo_list)].reset_index(drop=True)

# %%
df.head()

# %%
# Keep only the required columns
df = df[['REF_DATE', 'GEO', 'Work status', 'VALUE']]

# %%
df.head()

# %%
# Adding index column
df.insert(0, 'Index', range(1, len(df) + 1))

# %%
df

# %%
#pivoting the Graduation rate column
df_pivot = df.pivot(index=['REF_DATE', 'GEO', 'Index'], columns="Work status", values='VALUE').reset_index()

# %%
df_pivot.reset_index(drop=True, inplace=True)
df_pivot.columns

# %%
## Group the data by REF_DATE and GEO without setting them as index
grouped_df = df_pivot.groupby(['REF_DATE', 'GEO'], as_index=False).agg({
    'Index': 'first',  
    'Full-time educators': 'first',    
    'Part-time educators': 'first',
    'Total, work status': 'first'
})

# %%
grouped_df

# %%
#Dropping the Index column
grouped_df.drop(columns=['Index'], inplace=True)

# %%

# Remove column index name if it exists
grouped_df.columns.name = None  

# %%
grouped_df


# %%
grouped_df.to_csv("Prepared_Educators.csv", index=False)

# %%


# %%



