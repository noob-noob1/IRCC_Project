# %%
import pandas as pd
import os

# %%
# Define the folder path where the CSV files are located
folder_path = "."

# %%
# Get a list of all CSV files in the folder
csv_files = [file for file in os.listdir(folder_path) if file.endswith(".csv")]

# %%
# Initialize an empty list to store DataFrames
dfs = []

# Read each CSV file and append it to the list
for file in csv_files:
    file_path = os.path.join(folder_path, file)
    df = pd.read_csv(file_path)
    df['Source_File'] = file  # Optional: Track the file each row came from
    dfs.append(df)

# Concatenate all DataFrames
merged_df = pd.concat(dfs, ignore_index=True)

# %%
merged_df

# %%
# Keep only the left year
merged_df['REF_DATE'] = merged_df['REF_DATE'].str[:4]

# %%
merged_df

# %%
# Keep only the required columns
merged_df = merged_df[['REF_DATE', 'GEO', 'Graduation rate', 'VALUE']]

# %%
merged_df

# %%
# Adding index column
merged_df.insert(0, 'Index', range(1, len(merged_df) + 1))

# %%
merged_df

# %%
#pivoting the Graduation rate column
df_pivot = merged_df.pivot(index=['REF_DATE', 'GEO', 'Index'], columns="Graduation rate", values='VALUE').reset_index()

# %%
df_pivot

# %%
df_pivot.reset_index(drop=True, inplace=True)
df_pivot.columns

# %%
## Group the data by REF_DATE and GEO without setting them as index
grouped_df = df_pivot.groupby(['REF_DATE', 'GEO'], as_index=False).agg({
    'Index': 'first',  
    'Extended-time': 'first',    
    'On-time': 'first'  
})

# %%
grouped_df

# %%
#Dropping the Index column
grouped_df.drop(columns=['Index'], inplace=True)

# %%
# Remove column index name if it exists
grouped_df.columns.name = None  

# %%
grouped_df

# %%
# Define the list of GEO values to keep
geo_list = [
    "Canada", "Quebec", "Ontario", "British Columbia", "Alberta", 
    "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Saskatchewan", "Prince Edward Island"
]

# Filter the DataFrame to keep only these GEO values
grouped_df = grouped_df[grouped_df['GEO'].isin(geo_list)].reset_index(drop=True)

# %%
grouped_df

# %%
# Perform linear interpolation for numerical columns
grouped_df[['Extended-time', 'On-time']] = grouped_df[['Extended-time', 'On-time']].interpolate(method='linear')

# %%
grouped_df

# %%
grouped_df.to_csv("Prepared_GraduationRate.csv", index=False)

# %%



