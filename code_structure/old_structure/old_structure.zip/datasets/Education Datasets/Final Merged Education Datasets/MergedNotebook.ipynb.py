# %%
import pandas as pd
import numpy as np

# %%
educators_df = pd.read_csv("Prepared_Educators.csv")
epi_df = pd.read_csv("Prepared_EPI.csv")
expenditures_df = pd.read_csv("Prepared_Expenditures.csv")
graduation_df = pd.read_csv("Prepared_GraduationRate.csv")
participation_df = pd.read_csv("Prepared_ParticipationRate.csv")

# %%
#investigating the size of each dataset to get the right order of left joins
print(educators_df.shape)
print(epi_df.shape)
print(expenditures_df.shape)
print(graduation_df.shape)
print(participation_df.shape)

# %%

dataframes = [educators_df, epi_df, expenditures_df, graduation_df, participation_df]
    # Convert year into datetime format (assuming Jan 1st as default)
    # Ensure GEO is string format for consistency
for df in dataframes:
    # Convert year into datetime format (assuming Jan 1st as default)
    df["REF_DATE"] = pd.to_datetime(df["REF_DATE"].astype(str) + "-01-01")
    # Ensure GEO is string format for consistency
    df["GEO"] = df["GEO"].astype(str)

# %%
from functools import reduce

# Use reduce with an outer join to ensure no data is lost across time and geography
merged_df = reduce(lambda left, right: pd.merge(left, right, on=["REF_DATE", "GEO"], how="outer"), dataframes)

# Sort for readability and consistency
merged_df.sort_values(by=["REF_DATE", "GEO"], inplace=True)

# Convert REF_DATE to string format for display or export
merged_df["REF_DATE"] = merged_df["REF_DATE"].dt.strftime("%d-%m-%Y")

# %%
merged_df.info()

# %%
merged_df.head()

# %%
# Check overall missingness
missing_summary = merged_df.isnull().sum().sort_values(ascending=False)
missing_percent = (missing_summary / len(merged_df)) * 100

# Display columns with significant missing values
missing_report = pd.DataFrame({
    'Missing Count': missing_summary,
    'Missing %': missing_percent
}).query('`Missing %` > 0')

print(missing_report)


# %%
merged_df.to_csv("Final_Education_Dataset.csv")

# %%


# %%


# %%


# %%


# %%


# %%


# %%


# %%



