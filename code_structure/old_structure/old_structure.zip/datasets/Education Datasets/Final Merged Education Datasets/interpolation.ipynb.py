# %%
 #=== IMPORT LIBRARIES ===
import pandas as pd

# === LOAD DATASET ===
df = pd.read_csv("Final_Education_Dataset.csv")

# Drop index column if exists
df.drop(columns=["Unnamed: 0"], errors="ignore", inplace=True)

# %%
# === HANDLE MISSING DATA ===

# Drop columns with more than 90% missing values
missing_ratio = df.isnull().mean()
columns_to_drop = missing_ratio[missing_ratio > 0.90].index.tolist()
df.drop(columns=columns_to_drop, inplace=True)

# Convert REF_DATE to datetime and sort
df["REF_DATE"] = pd.to_datetime(df["REF_DATE"], format="%d-%m-%Y", errors='coerce')
df.sort_values(by=["GEO", "REF_DATE"], inplace=True)

# Interpolate numeric columns only within each GEO group
numeric_cols = df.select_dtypes(include="number").columns
df[numeric_cols] = df.groupby("GEO")[numeric_cols].transform(lambda group: group.interpolate(method='linear'))

# Fill remaining missing values with group-wise (province-level) mean
df[numeric_cols] = df.groupby("GEO")[numeric_cols].transform(lambda group: group.fillna(group.mean()))

# Final fallback: fill any remaining NaNs with overall column means
df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())


# %%
# === FEATURE ENGINEERING ===

# Avoid division by zero
df.replace(0, pd.NA, inplace=True)

# 1. Educator-to-operating spending ratio
df["Educator_to_OperatingSpending"] = df["Total, work status"] / df["Total operating expenditures"]

# 2. Salary-to-EPI ratio
df["Salary_to_EPI"] = df["Teachers salaries"] / df["Education price index (EPI)"]

# 3. Operational spend per educator
df["OpSpend_per_Educator"] = df["Total operating expenditures"] / df["Total, work status"]

# 4. Education Access Index: average of participation rates
participation_cols = ["College", "Elementary and/or High School", "University"]
if all(col in df.columns for col in participation_cols):
    df["Education_Access_Index"] = df[participation_cols].mean(axis=1)

# 5. Capital efficiency
if "Teachers' salaries sub-index" in df.columns and "Total expenditures" in df.columns:
    df["Capital_Efficiency"] = df["Total expenditures"] / df["Teachers' salaries sub-index"]


# %%
df.head()

# %%
df.sort_values(by="REF_DATE", inplace=True)

# %%
df.head()

# %%
# === FINAL CLEANUP ===
df["REF_DATE"] = pd.to_datetime(df["REF_DATE"], errors='coerce')  # Ensure REF_DATE is in datetime format
df["REF_DATE"] = df["REF_DATE"].dt.strftime("%d-%m-%Y")

# === EXPORT CLEANED AND ENHANCED DATA ===
df.to_csv("Enhanced_Education_Dataset.csv", index=False)
print("✅ Cleaned and enhanced dataset saved as 'Enhanced_Education_Dataset.csv'")

# %%


# %%



