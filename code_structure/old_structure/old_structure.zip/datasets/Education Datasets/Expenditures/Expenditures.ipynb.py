# %%
import pandas as pd

# %%
file_path = "Elementary and secondary private schools, by type of expenditure.csv"
df = pd.read_csv(file_path)

# %%
df.head()

# %%
# Keep only the left year
df['REF_DATE'] = df['REF_DATE'].str[:4]

# %%
df.head()

# %%
# Keep only the required columns
df = df[['REF_DATE', 'GEO', 'Type of expenditure', 'VALUE']]

# %%
df.head()

# %%
# Filter the dataframe
filtered_df = df[df["Type of expenditure"].isin([
    "Total expenditures",
    "Total operating expenditures",
    "Teachers salaries",
    "Capita outlay and debt charges"
])]

# %%
filtered_df

# %%
# Define the list of GEO values to keep
geo_list = [
    "Canada", "Quebec", "Ontario", "British Columbia", "Alberta", 
    "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Saskatchewan", "Prince Edward Island"
]

# Filter the DataFrame to keep only these GEO values
filtered_df = filtered_df[filtered_df['GEO'].isin(geo_list)].reset_index(drop=True)

# %%
filtered_df

# %%
# Adding index column
filtered_df.insert(0, 'Index', range(1, len(filtered_df) + 1))

# %%
filtered_df

# %%
#pivoting the Graduation rate column
df_pivot = filtered_df.pivot(index=['REF_DATE', 'GEO', 'Index'], columns="Type of expenditure", values='VALUE').reset_index()

# %%
df_pivot

# %%
df_pivot.reset_index(drop=True, inplace=True)
df_pivot.columns

# %%
## Group the data by REF_DATE and GEO without setting them as index
grouped_df = df_pivot.groupby(['REF_DATE', 'GEO'], as_index=False).agg({
    'Index': 'first',  
    'Capita outlay and debt charges': 'first',    
    'Teachers salaries': 'first',
    'Total expenditures': 'first',
    'Total operating expenditures': 'first'
})

# %%

grouped_df

# %%
#Dropping the Index column
grouped_df.drop(columns=['Index'], inplace=True)

# %%

# Remove column index name if it exists
grouped_df.columns.name = None  

# %%
grouped_df

# %%
grouped_df = grouped_df.interpolate(method='linear')

# %%
grouped_df = grouped_df.drop(columns=["Capita outlay and debt charges"])

# %%
grouped_df

# %%
grouped_df.to_csv("Prepared_Expenditures.csv", index=False)


# %%



