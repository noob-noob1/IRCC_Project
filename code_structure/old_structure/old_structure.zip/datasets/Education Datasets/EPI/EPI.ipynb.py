# %%

import pandas as pd

# %%
file_path = "Education price index (EPI), elementary and secondary.csv"
df = pd.read_csv(file_path)

# %%
df.head()

# %%
# Define the list of GEO values to keep
geo_list = [
    "Canada", "Quebec", "Ontario", "British Columbia", "Alberta", 
    "Manitoba", "New Brunswick", "Newfoundland and Labrador", 
    "Nova Scotia", "Saskatchewan", "Prince Edward Island"
]

# Filter the DataFrame to keep only these GEO values
df = df[df['GEO'].isin(geo_list)].reset_index(drop=True)

# %%
df

# %%
# Keep only the required columns
df = df[['REF_DATE', 'GEO', 'Index categories', 'VALUE']]

# %%
df.head()

# %%
# Adding index column
df.insert(0, 'Index', range(1, len(df) + 1))

# %%
df.head()

# %%
#pivoting the Graduation rate column
df_pivot = df.pivot(index=['REF_DATE', 'GEO', 'Index'], columns="Index categories", values='VALUE').reset_index()

# %%
df_pivot

# %%

df_pivot.reset_index(drop=True, inplace=True)
df_pivot.columns

# %%
grouped_df = df_pivot.groupby(['REF_DATE', 'GEO'], as_index=False).agg({
    "Index": "first",
    "Education price index (EPI)": "first",
    "Fees and contractual services sub-index": "first",
    "Instructional supplies sub-index": "first",
    "Non-salary sub-index": "first",
    "Non-teaching salaries sub-index": "first",
    "Salaries and wages sub-index": "first",
    "School facilities, supplies and services sub-index": "first",
    "Teachers' salaries sub-index": "first"  # No issue inside double quotes
})


# %%
grouped_df


# %%
#Dropping the Index column
grouped_df.drop(columns=['Index'], inplace=True)

# %%
grouped_df

# %%

# Remove column index name if it exists
grouped_df.columns.name = None  

# %%
grouped_df

# %%
grouped_df.to_csv("Prepared_EPI.csv", index=False)

# %%


# %%



